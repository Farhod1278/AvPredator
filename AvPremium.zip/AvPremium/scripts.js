document.addEventListener('DOMContentLoaded', function() {
    // DOM Elements
    const multiplierDisplay = document.getElementById('multiplier');
    const predictBtn = document.getElementById('predict-btn');
    const resetBtn = document.getElementById('reset-btn');
    const avgMultiplier = document.getElementById('avg-multiplier');
    const maxMultiplier = document.getElementById('max-multiplier');
    const predictionCount = document.getElementById('prediction-count');
    const historyList = document.getElementById('history-list');
    const plane = document.getElementById('plane');
    const lastMultiplierInput = document.getElementById('last-multiplier');
    const movingStrings = document.getElementById('moving-strings');
    const supportBtn = document.getElementById('support-btn');
    const walletAddress = document.getElementById('wallet-address');

    // Create moving strings in the background
    function createMovingStrings() {
        for (let i = 0; i < 30; i++) {
            const string = document.createElement('div');
            string.className = 'string';
            
            // Random position
            const left = Math.random() * 100;
            string.style.left = `${left}%`;
            
            // Random height
            const height = 50 + Math.random() * 150;
            string.style.height = `${height}px`;
            
            // Random speed/duration
            const duration = 5 + Math.random() * 15;
            string.style.animationDuration = `${duration}s`;
            
            // Random delay
            const delay = Math.random() * 10;
            string.style.animationDelay = `${delay}s`;
            
            movingStrings.appendChild(string);
        }
    }

    // State variables
    let history = [];
    let isAnimating = false;

    // Generate a random multiplier based on the specified distribution
    function generateMultiplier(lastMultiplier = null) {
        if (lastMultiplier) {
            if (lastMultiplier > 10) {
                const rand = Math.random();
                if (rand < 0.7) {
                    return (1 + Math.random() * 2).toFixed(2);
                } else if (rand < 0.95) {
                    return (3 + Math.random() * 7).toFixed(2);
                } else {
                    return (10 + Math.random() * (lastMultiplier * 0.8)).toFixed(2);
                }
            } else if (lastMultiplier < 1.5) {
                const rand = Math.random();
                if (rand < 0.5) {
                    return (1 + Math.random() * 2).toFixed(2);
                } else if (rand < 0.9) {
                    return (3 + Math.random() * 10).toFixed(2);
                } else {
                    return (13 + Math.random() * 40).toFixed(2);
                }
            }
        }

        const rand = Math.random();
        if (rand < 0.9) {
            if (rand < 0.45) {
                return (1 + Math.random()).toFixed(2);
            } else {
                return (2 + Math.random() * 3).toFixed(2);
            }
        } else if (rand < 0.999) {
            return (5 + Math.random() * 45).toFixed(2);
        } else {
            return (50 + Math.random() * 250).toFixed(2);
        }
    }

    // Update stats
    function updateStats() {
        if (history.length > 0) {
            const sum = history.reduce((acc, val) => acc + val, 0);
            const avg = sum / history.length;
            const max = Math.max(...history);
            
            avgMultiplier.textContent = avg.toFixed(2);
            maxMultiplier.textContent = max.toFixed(2);
            predictionCount.textContent = history.length;
        } else {
            avgMultiplier.textContent = '0.00';
            maxMultiplier.textContent = '0.00';
            predictionCount.textContent = '0';
        }
    }

    // Update history list
    function updateHistoryList() {
        historyList.innerHTML = '';
        const recentHistory = history.slice(-10);
        
        recentHistory.forEach(multiplier => {
            const historyItem = document.createElement('div');
            historyItem.className = 'history-item';
            
            if (multiplier <= 2) {
                historyItem.classList.add('highlight-low');
            } else if (multiplier <= 10) {
                historyItem.classList.add('highlight-medium');
            } else {
                historyItem.classList.add('highlight-high');
            }
            
            historyItem.textContent = multiplier.toFixed(2);
            historyList.prepend(historyItem);
        });
    }

    // Initialize distribution chart
    let distributionChart;

    function initChart() {
        const ctx = document.getElementById('distribution-chart').getContext('2d');
        const labels = ['1x-2x', '2x-5x', '5x-50x', '50x-300x'];
        const data = [50, 40, 9.9, 0.1]; // Percentages
        
        distributionChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: labels,
                datasets: [{
                    label: 'Probability (%)',
                    data: data,
                    backgroundColor: [
                        'rgba(255, 0, 0, 0.7)',
                        'rgba(255, 0, 0, 0.5)',
                        'rgba(255, 165, 2, 0.7)',
                        'rgba(46, 213, 115, 0.7)'
                    ],
                    borderColor: [
                        'rgba(255, 0, 0, 1)',
                        'rgba(255, 0, 0, 1)',
                        'rgba(255, 165, 2, 1)',
                        'rgba(46, 213, 115, 1)'
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                return context.raw + '% probability';
                            }
                        }
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        max: 60,
                        grid: {
                            color: 'rgba(255, 255, 255, 0.1)'
                        },
                        ticks: {
                            color: 'rgba(255, 255, 255, 0.7)'
                        }
                    },
                    x: {
                        grid: {
                            display: false
                        },
                        ticks: {
                            color: 'rgba(255, 255, 255, 0.7)'
                        }
                    }
                }
            }
        });
    }

    // Animation for the multiplier reveal
    function animateMultiplier(multiplier) {
        isAnimating = true;
        plane.classList.add('active');
        
        let startValue = 1.00;
        const duration = Math.min(multiplier * 100, 3000); // Cap at 3 seconds
        const startTime = Date.now();
        
        function updateCounter() {
            const currentTime = Date.now();
            const elapsedTime = currentTime - startTime;
            
            if (elapsedTime < duration) {
                const progress = elapsedTime / duration;
                const easedProgress = progress < 0.5 
                    ? 2 * progress * progress 
                    : 1 - Math.pow(-2 * progress + 2, 2) / 2;
                
                const currentValue = startValue + (multiplier - startValue) * easedProgress;
                multiplierDisplay.textContent = currentValue.toFixed(2);
                requestAnimationFrame(updateCounter);
            } else {
                multiplierDisplay.textContent = multiplier.toFixed(2);
                multiplierDisplay.classList.add('pulse');
                
                if (multiplier <= 2) {
                    multiplierDisplay.className = 'multiplier-display highlight-low pulse';
                } else if (multiplier <= 10) {
                    multiplierDisplay.className = 'multiplier